from django.db import models
from master.models import VendorDetail ,CustomerDetail,category

# Create your models here.
class InwardMaterial(models.Model):
    invoice_no = models.CharField(max_length=50)
    invoice_date = models.DateField()
    vendor = models.ForeignKey(VendorDetail, on_delete=models.CASCADE)  # Linked to Vendor
    grn_no = models.CharField(max_length=50)
    grn_date = models.DateField()
    received_date = models.DateField()
    store = models.CharField(max_length=100)
    po_no = models.ForeignKey(CustomerDetail, on_delete=models.CASCADE)  # Assuming PO is linked to Customers
    po_date = models.DateField()
    remarks = models.TextField(blank=True, null=True)
    bag_type = models.ForeignKey(category, on_delete=models.CASCADE)  # Assuming bag types are stored in category

    def __str__(self):
        return self.invoice_no


class RawInwardMaterialSub(models.Model):
    inward_material = models.ForeignKey(InwardMaterial, on_delete=models.CASCADE, related_name="raw_materials")
    item_code = models.CharField(max_length=50)
    item_name = models.CharField(max_length=255)
    uom = models.CharField(max_length=50)
    quantity = models.IntegerField()
    no_of_boxes = models.IntegerField()
    received_date = models.DateField()

    def __str__(self):
        return self.item_name

