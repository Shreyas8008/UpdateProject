from django.shortcuts import render
from django.shortcuts import render, redirect, get_object_or_404
from django.contrib.auth.forms import AuthenticationForm
from .forms import InwardMaterialForm,RawInwardMaterialSubForm
from .models import InwardMaterial,RawInwardMaterialSub
from django.http import JsonResponse
import json

def inward_material_list(request):
    inward_materials = InwardMaterial.objects.all()
    return render(request, 'packing_material/inward_material_list.html', {'inward_materials': inward_materials})

def inward_material_add(request):
    if request.method == "POST":
        form = InwardMaterialForm(request.POST)
        if form.is_valid():
            form.save()
            return JsonResponse({"message": "Success", "redirect": "inward_material_list"})
    else:
        form = InwardMaterialForm()
    
    if request.headers.get("X-Requested-With") == "XMLHttpRequest":
        return JsonResponse({
            "html": render(request, 'packing_material/inward_material_form.html', {'form': form}).content.decode('utf-8')
        })
    
    return render(request, "packing_material/inward_material_form.html", {"form": form})
def inward_material_view(request, id):
    inward_material = get_object_or_404(InwardMaterial, pk=id)
    return render(request, 'packing_material/inward_material_view.html', {'inward_material': inward_material})

def inward_material_edit(request, id):
    inward_material = get_object_or_404(InwardMaterial, pk=id)
    if request.method == "POST":
        form = InwardMaterialForm(request.POST, instance=inward_material)
        if form.is_valid():
            form.save()
            return redirect('inward_material_display')
    else:
        form = InwardMaterialForm(instance=inward_material)
    
    return JsonResponse({'html': render(request, 'packing_material/inward_material_form.html', {'form': form}).content.decode('utf-8')})

def inward_material_delete(request, id):
    inward_material = get_object_or_404(InwardMaterial, pk=id)
    inward_material.delete()
    return redirect('inward_material_display')

def inward_material_form(request):
    if request.method == "POST":
        inward_material_id = request.POST.get("inward_material_id")
        
        if inward_material_id:
            inward_material = get_object_or_404(InwardMaterial, id=inward_material_id)
            form = InwardMaterialForm(request.POST, instance=inward_material)
        else:
            form = InwardMaterialForm(request.POST)
        
        if form.is_valid():
            inward_material = form.save(commit=False)
            inward_material.vendor_id = request.POST.get("vendor")
            inward_material.po_no_id = request.POST.get("po_no")
            inward_material.bag_type_id = request.POST.get("bag_type")
            inward_material.save()
            
            item_codes = request.POST.getlist("item_code[]")
            item_names = request.POST.getlist("item_name[]")
            uoms = request.POST.getlist("uom[]")
            quantities = request.POST.getlist("quantity[]")
            no_of_boxes = request.POST.getlist("no_of_boxes[]")
            received_dates = request.POST.getlist("received_date[]")
            
            formatted_received_dates = [datetime.strptime(date, "%Y-%m-%d").date() for date in received_dates]
            
            if inward_material_id:
                inward_material.raw_materials.all().delete()
            
            child_entries = [
                RawInwardMaterialSub(
                    inward_material=inward_material,
                    item_code=item_codes[i],
                    item_name=item_names[i],
                    uom=uoms[i],
                    quantity=int(quantities[i]) if quantities[i] else 0,
                    no_of_boxes=int(no_of_boxes[i]) if no_of_boxes[i] else 0,
                    received_date=formatted_received_dates[i],
                ) for i in range(len(item_codes))
            ]
            RawInwardMaterialSub.objects.bulk_create(child_entries)
            
            return JsonResponse({"message": "Success", "redirect": "inward_material_display"})
        else:
            return JsonResponse({"error": form.errors}, status=400)
    
    return JsonResponse({'html': render(request, "packing_material/inward_material_form.html", {"form": InwardMaterialForm(), "title": "Add Inward Material"}).content.decode('utf-8')})

def save_child_data(request):
    if request.method == "POST":
        try:
            data = json.loads(request.body)
            inward_material = InwardMaterial.objects.get(id=data["inward_material_id"])
            
            for item in data["items"]:
                RawInwardMaterialSub.objects.create(
                    inward_material=inward_material,
                    item_code=item["item_code"],
                    item_name=item["item_name"],
                    uom=item["uom"],
                    quantity=item["quantity"],
                    no_of_boxes=item["no_of_boxes"],
                    received_date=datetime.strptime(item["received_date"], "%Y-%m-%d").date(),
                )
            return JsonResponse({"message": "Child data saved successfully!"}, status=200)
        except Exception as e:
            return JsonResponse({"error": str(e)}, status=400)
    return JsonResponse({"error": "Invalid request method"}, status=405)

