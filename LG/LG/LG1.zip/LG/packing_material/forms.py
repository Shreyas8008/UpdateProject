from django import forms
from .models import InwardMaterial,RawInwardMaterialSub
class InwardMaterialForm(forms.ModelForm):
    class Meta:
        model = InwardMaterial
        fields = '__all__'
        widgets = {
            'invoice_date': forms.DateInput(attrs={'type': 'date'}),
            'grn_date': forms.DateInput(attrs={'type': 'date'}),
            'received_date': forms.DateInput(attrs={'type': 'date'}),
            'po_date': forms.DateInput(attrs={'type': 'date'}),
        }


class RawInwardMaterialSubForm(forms.ModelForm):
    class Meta:
        model = RawInwardMaterialSub
        fields = ['item_code', 'item_name', 'uom', 'quantity', 'no_of_boxes', 'received_date']
        widgets = {
            'received_date': forms.DateInput(attrs={'type': 'date'}),
        }

