﻿from django.urls import path
from . import views
from .views import inward_material_list,inward_material_view,inward_material_edit,inward_material_delete,inward_material_form,save_child_data
from django.contrib.auth import views as auth_views
urlpatterns = [
  path("inward-material/", views.inward_material_list, name="inward_material_list"),  
  path("inward-material/add/", views.inward_material_add, name="inward_material_add"),  # ✅ Ensure this line exists

    # View details
    path("inward-material/view/<int:id>/", views.inward_material_view, name="inward_material_view"),  
    
    # Update record
    path("inward-material/edit/<int:id>/", views.inward_material_edit, name="inward_material_edit"),  
    
    # Delete record
    path("inward-material/delete/<int:id>/", views.inward_material_delete, name="inward_material_delete"),  

    # Inward Material Form (shouldn't have same URL as view)
    path("inward-material/form/", views.inward_material_form, name="inward_material_form"),  

    # AJAX Route for Saving Child Data
    path("save-child-data/", views.save_child_data, name="save_child_data"), 
]
